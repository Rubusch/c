// apla.c
/*
  The AgentPLAtform dummy.
//*/

#include "mq_message.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h> // fork
#include <unistd.h> // fork, execlp
#include <sys/types.h> // ftok(), msgget(), msgsnd(), kill()
#include <sys/ipc.h> // ftok(), msgget(), msgsnd()
#include <sys/msg.h> // msgget(), msgsnd()
#include <signal.h> // kill()
#include <errno.h> // errno


/************************************ apla tools *********************************************/
#ifndef _APLA_
#define _APLA_


// constants
typedef enum error_code_s{
  ERRCODE_SUCCESS = 0,
  ERRCODE_FAILURE
} error_code_t;

#define STRSIZ 64
#define STRLEN 63

#define TEXTSIZ 4096
#define TEXTLEN 4095


// string
int
string_len( const char* str, const unsigned int siz)
{
  if(!str) return -1;

#ifdef _GNU_SOURCE
  return strnlen( str, siz);
#else
  int len = -1;
  for( len=0; (str[len] != '\0') && (len < siz); ++len)
    ;
  return len;
#endif
}

char*
string_cat( char* dst, const char* src )
{
  return strncat( dst, src, string_len( src, TEXTLEN ) );
}

int 
string_cmp( const char* sz1, const char* sz2)
{
  return strncmp( sz1, sz2, (string_len(sz1, TEXTLEN) > string_len(sz2, TEXTLEN) ? 1+string_len(sz2, TEXTLEN) : 1+string_len(sz1, TEXTLEN)) );
}

char*
string_cpy( char* dst, const char* src )
{
  return strncpy( dst, src, 1+string_len(src, TEXTLEN) );
}

// set debugging level: 0, 1 or 2
#define DEBUGLEVEL 1

#if DEBUGLEVEL > 0

# define DBUG1( message ) \
  fprintf( stderr, "DEBUG (%s, %d): %s\n", __FILE__, __LINE__, message);
# define DBUG1_A \
  fprintf( stderr, "DEBUG (%s, %d): ", __FILE__, __LINE__); \
  fprintf( stderr,
# define DBUG1_B \
  );
# if DEBUGLEVEL > 1
#  define DBUG2( message ) \
  DBUG1( message )
#  define DBUG2_A \
  DBUG1_A
#  define DBUG2_B \
  DBUG1_B
# else
void dummy( void* arg, ...){}
#  define DBUG2( message ) \
  dummy( message );
#  define DBUG2_A \
  dummy(
#  define DBUG2_B \
  );
# endif // DEBUGLEVEL > 1

#else

void dummy( void* arg, ...){}
# define DBUG1( message ) \
  dummy( message );
# define DBUG1_A \
  dummy(
# define DBUG1_B \
  );
# define DBUG2( message ) \
  DBUG1( message )
# define DBUG2_A \
  DBUG1_A
# define DBUG2_B \
  DBUG1_B

#endif


// error
#define ERR( message )                                                  \
  fprintf( stderr, "ERROR (%s, %d): %s\n", __FILE__, __LINE__, message );
#define ERR_A \
  fprintf( stderr, "ERROR (%s, %d): ", __FILE__, __LINE__ );   \
  fprintf( stderr,
#define ERR_B \
  );


// memory
// allocates a size (like malloc)
#define MEM_TYPEALLOC( ptr, typesize )              \
  if(NULL == (ptr = malloc( typesize ))){           \
    ERR( "Allocation failed!" );                    \
    exit( -1 );                                 \
  }

// allocates a number of the type of ptr (like calloc)
#define MEM_ALLOC( ptr, size )                     \
  if(NULL == (ptr = calloc( sizeof(*ptr), size))){ \
    ERR( "Allocation failed." );                 \
    exit( -1 );                                    \
  } 

// allocates a number of chars and inits to '\0'
#define MEM_STRALLOC( ptr, size )                  \
  if(NULL == (ptr = calloc( sizeof(*ptr), size))){ \
    ERR( "Allocation failed." );                 \
    exit( -1 );                                    \
  } \
  memset( ptr, '\0', size * sizeof(*ptr));

// reallocates to oldsize + addsize
#define MEM_REALLOC( ptr, oldsize, addsize ) \
  char* _tmp = NULL;                                           \
  if( NULL == (_tmp = realloc( ptr, (oldsize + addsize) ) ) ){ \
    ERR( "Reallocation failed." );                           \
    exit( -1 );                                                \
  }                                                            \
  ptr = _tmp; 

// duplicate string, by allocation
char*
MEM_STRDUP( const char* src )
{
  int src_len=-1;
  char* ret=NULL;
  if( TEXTLEN == (src_len = string_len( src, TEXTLEN ) ) ){
    ((char*) src)[TEXTLEN] = '\0';
  }
#ifdef _GNU_SOURCE
  ret = strndup( src, 1+src_len );
#else
  ret = strdup( src );
#endif
  if(ret == NULL){
    ERR( "Duplication failed." );
    exit(-1);
  }
  return ret;
}

// free
#define MEM_FREE( ptr )                         \
  if(ptr) free( ptr );                          \
  ptr = NULL; 


#endif  // _APLA_ tools
/*********************************************************************************************/


error_code_t
forkProcess( char* processname, char* processargs, pid_t* pid, int* status )
{
  int ret;
  char buf[STRSIZ]; memset(buf, '\0', STRSIZ * sizeof(*buf) );
    
  *pid = fork();
  if( 0 > *pid ){ // fail
    ERR( "fork() failed!" );
    return ERRCODE_FAILURE;
    
  }else if( 0 == *pid ){ // child
    if( !processargs ){
      string_cat( buf, "./" );
      string_cat( buf, processname );
      ret = execvp( buf, NULL );

    }else if( 0 == string_len( processargs, STRLEN ) ){
      string_cat( buf, "./" );
      string_cat( buf, processname );
      ret = execvp( buf, NULL);
      
    }else{
      ret = execlp( processname, processname, processargs, ".", (char*) 0);
    }
    
    if(0 != ret){
      memset( buf, '\0', STRSIZ * sizeof(*buf) );
      strerror_r( ret, buf, STRSIZ );
      ERR_A "Process execution failed: \"%s\"!", buf ERR_B;
      return ERRCODE_FAILURE;
    }
    
  }else{ // parent        
    return ERRCODE_SUCCESS; 
  }
  return ERRCODE_SUCCESS;
}


// needs to be declared globally or mq_recv() seg-faults exiting the function scope
static MQ_Message g_mq_message;

// sends of type '1'
error_code_t
mq_send( const int mq_id, const char* cmd )
{
  DBUG2( "mq_send()" );
  DBUG1_A "server -> mq: \"%s\"\n", cmd DBUG1_B;

  char errmsg[STRSIZ]; memset( errmsg, '\0', STRSIZ );

  memset( g_mq_message.cmd, '\0', MQ_MESSAGESIZ * sizeof( *g_mq_message.cmd ) );
  g_mq_message.mtype = 1;

  string_cpy( g_mq_message.cmd, cmd );
  if( 0 > msgsnd( mq_id, &g_mq_message, sizeof( g_mq_message ), IPC_NOWAIT ) ){
    strerror_r( errno, errmsg, STRSIZ );
    ERR_A "msgsend ERROR: \"%s\".\n", errmsg ERR_B;
    return ERRCODE_FAILURE;
  }
  
  return ERRCODE_SUCCESS;
}

// receives of type '2'
error_code_t
mq_recv( const int mq_id, char* cmd )
{
  DBUG2( "mq_recv()" );

  int mq_mtype;
  char errmsg[STRSIZ]; memset( errmsg, '\0', STRSIZ );

  memset( g_mq_message.cmd, '\0', MQ_MESSAGESIZ * sizeof( *g_mq_message.cmd ) );
  mq_mtype = 2;
 
  if( 0 > msgrcv( mq_id, &g_mq_message, sizeof( g_mq_message ), mq_mtype, IPC_NOWAIT ) ){
    strerror_r(errno, errmsg, STRSIZ);
    ERR_A "msgrcv ERROR: \"%s\".\n", errmsg ERR_B;
    return ERRCODE_FAILURE;
  }
  string_cpy( cmd, g_mq_message.cmd );

  DBUG1_A "mq -> server: \"%s\"\n", cmd DBUG1_B;

  return ERRCODE_SUCCESS;
}


// main
int main( int argc, char** argv )
{
  pid_t pid;
  int status = 0;
  char cmd[MQ_MESSAGESIZ]; memset(cmd, '\0', sizeof(*cmd) * MQ_MESSAGESIZ);
  key_t mq_key;
  int mq_flags = 0;
  int mq_id = 0;

  DBUG2( "init mq" );
  
  // init mq
  if( 0 > (mq_key = ftok( "/tmp", 'B' ) ) ){
    ERR( "ftok ERROR" );
    exit( EXIT_FAILURE );
  }
  mq_flags = IPC_CREAT | 0666;
  mq_id = 0;
  if( 0 > (mq_id = msgget( mq_key, mq_flags ) ) ){
    ERR( "msgget ERROR" );
    exit( EXIT_FAILURE );
  }
    
  forkProcess( "counter.exe", "", &pid, &status );
  
  // "start"
  if( ERRCODE_SUCCESS != mq_send( mq_id, "start" ) ){
    kill(pid, 9);  
    exit( EXIT_FAILURE );
  }
  sleep( 5 );
  
  // "stop"
  if( ERRCODE_SUCCESS != mq_send( mq_id, "stop" ) ){
    kill(pid, 9);  
    exit( EXIT_FAILURE );
  }
  sleep(5);

  // confirmation
  memset(cmd, '\0', sizeof(*cmd) * MQ_MESSAGESIZ);
  if( ERRCODE_SUCCESS != mq_recv( mq_id, cmd) ){
    kill( pid, 9 );
    exit( EXIT_FAILURE );
  }
  sleep(5);
  
  // "start"
  if( ERRCODE_SUCCESS != mq_send( mq_id, "start" ) ){
    kill(pid, 9);  
    exit( EXIT_FAILURE );
  }
  sleep( 5 );
  
  // "stop"
  if( ERRCODE_SUCCESS != mq_send( mq_id, "stop" ) ){
    kill(pid, 9);  
    exit( EXIT_FAILURE );
  }
  sleep(5);

  // confirmation
  memset(cmd, '\0', sizeof(*cmd) * MQ_MESSAGESIZ);
  if( ERRCODE_SUCCESS != mq_recv( mq_id, cmd) ){
    kill( pid, 9 );
    exit( EXIT_FAILURE );
  }
  sleep(5);


  kill(pid, 9);  
  exit( EXIT_SUCCESS );
}
