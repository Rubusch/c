readme

message queue interface demo.

build:
> make

start:
./apla.exe

verbosity:
DEBUGLEVEL in apla.c allows 0, 1 or 2

