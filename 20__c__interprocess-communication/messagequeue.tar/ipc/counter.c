// counter.c
/*
  The "external process" dummy.
//*/


#ifndef _COUNTER_H_
#define _COUNTER_H_


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> // ftok(), msgget(), msgsnd()
#include <sys/ipc.h> // ftok(), msgget(), msgsnd()
#include <sys/msg.h> // msgget(), msgsnd()
#include <pthread.h>

#include "mq_message.h"


typedef struct{
  pthread_mutex_t lock;
  int running;
} State_t;
State_t g_state;

pthread_mutex_t mxcd_count = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_count = PTHREAD_COND_INITIALIZER;

pthread_t tid_ipcom, tid_dosomething;


void* 
thr_ipcom( void* arg );


void*
thr_dosomething( void* arg );


#endif // _COUNTER_H_


void* thr_ipcom(void* arg)
{
  key_t mq_key = 0;
  int mq_id, mq_flags;
  MQ_Message mq_message; 

  fprintf( stderr, "COUNTER - thr_ipcom started\n");

  // join existing mq  
  if( 0 > (mq_key = ftok( "/tmp", 'B' ) ) ){
    perror( "COUNTER - ftok ERROR" );
    exit( EXIT_FAILURE );
  }
  mq_flags = 0666;
  if( 0 > (mq_id = msgget( mq_key, mq_flags ) ) ){
    perror( "COUNTER - msgget ERROR" );
    exit( EXIT_FAILURE );
  }

  do{
    // receive, mtype == '1'
    if( 0 > (msgrcv( mq_id, &mq_message, sizeof( mq_message ), 1, 0 ) ) ){
      perror( "COUNTER - msgrcv ERROR" );
      exit( EXIT_FAILURE );
    }

    pthread_mutex_lock( &g_state.lock );
    g_state.running = ( ( !strncmp("start", mq_message.cmd, MQ_MESSAGESIZ) ? 1 : 0 ) );
    pthread_mutex_unlock( &g_state.lock );

    pthread_mutex_lock( &mxcd_count );
    if( !strncmp( mq_message.cmd, "start", MQ_MESSAGESIZ ) ){
      pthread_cond_signal( &cond_count );
    }
    pthread_mutex_unlock( &mxcd_count );

    // send confirmation if received message was "stop"
    if( 0 < strlen( mq_message.cmd ) ){
      if( !strncmp( mq_message.cmd, "stop", MQ_MESSAGESIZ ) ){
        strncpy( mq_message.cmd, "Confirmation: counter received message \'stop\'!", MQ_MESSAGESIZ );
        // send, mtype == '2'
        mq_message.mtype = 2;
        if( 0 > (msgsnd( mq_id, &mq_message, sizeof( mq_message ), IPC_NOWAIT ) ) ){
          perror( "COUNTER - msgsnd ERROR" );
          exit( EXIT_FAILURE );
        }
        memset(mq_message.cmd, '\0', MQ_MESSAGESIZ * sizeof(*mq_message.cmd) );
      }
    }

  }while( 1 );

  pthread_exit( NULL );
}


void* thr_dosomething( void* arg )
{  
  fprintf( stderr, "COUNTER - thr_dosomething started\n");

  int cnt = 0;
  int running = 0;

  do{
    // some delay
    sleep( 1 );

    pthread_mutex_lock( &g_state.lock );
    running = g_state.running;
    pthread_mutex_unlock( &g_state.lock );

    // in case suspend thread
    pthread_mutex_lock( &mxcd_count );
    if( !running ){ 
      pthread_cond_wait( &cond_count, &mxcd_count );
    }
    pthread_mutex_unlock( &mxcd_count );

    // do something
    ++cnt;
    fprintf( stderr, "COUNTER - \"%d\"\n", cnt );

  }while( cnt < 100 );

  pthread_exit( NULL );
}


int
main( int argc, char** argv)
{
  puts("COUNTER - started");

  // init
  g_state.running = 0;
  if(0 != pthread_mutex_init( &g_state.lock, NULL ) ){
    perror( "COUNTER - pthread_mutex_init ERROR" );
    exit( EXIT_FAILURE );
  }

  // start threads
  if( 0 != pthread_create( &tid_ipcom, NULL, &thr_ipcom, NULL ) ){
    perror( "COUNTER - thr_ipcom ERROR" );
    exit( EXIT_FAILURE );
  }
  if( 0 != pthread_create( &tid_dosomething, NULL, &thr_dosomething, NULL ) ){
    perror( "COUNTER - thr_dosomething ERROR" );
    exit( EXIT_FAILURE );
  }

  // join
  pthread_join( tid_ipcom, NULL );
  pthread_join( tid_dosomething, NULL );

  puts("COUNTER - terminated"); 
  return EXIT_SUCCESS;
}
