// mq_message.h

#ifndef _MQ_MESSAGE_H_
#define _MQ_MESSAGE_H_


#define MQ_MESSAGESIZ 256

typedef struct{
  long mtype;
  char cmd[MQ_MESSAGESIZ];
} MQ_Message;


#endif
